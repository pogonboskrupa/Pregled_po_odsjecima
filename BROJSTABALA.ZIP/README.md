# Unsko-sanske Šume — Distribucija broja stabala

**Izvor:** ŠPD "Unsko-sanske šume" DOO, Bosanska Krupa  
**Datum exporta:** 06.05.2026.  
**Opis:** Distribucija broja stabala i temeljnica po odsjecima (grupirano) — selektovane gospodarske jedinice iz Šumskog gazdinstva 01 UNSKO.

## Gospodarske jedinice u ovom datasetu

| GJ br. | Naziv |
|--------|-------|
| 06 | GOMILA |
| 07 | BAŠTRA ĆORKOVAČA |
| 08 | VOJSKOVA |
| 09 | RISOVAC KRUPA |
| 10 | GRMEČ JASENICA |

## Fajlovi

| Fajl | Opis |
|------|------|
| `unsko_stabala.csv` | Svi podaci u CSV formatu (UTF-8, zarez separator) |
| `unsko_stabala.xlsx` | Isti podaci u Excel formatu (6 listova: pregled + po GJ) |

## Struktura CSV-a

```
Gosp. Jed., Odjel, Odsjek, Povr. (ha), Gazd. Klasa, Vrsta, Šifra, Naziv drveta,
Bonitet, Kl. 0-5, Kl. 6-10, Kl. 11-20, Kl. 21-30, Kl. 31-50, Kl. 51-80, Kl. >80,
Ukupno, Temeljnica (m²/ha), Tip
```

### Opis kolona

| Kolona | Tip | Opis |
|--------|-----|------|
| `Gosp. Jed.` | string | Naziv gospodarske jedinice |
| `Odjel` | integer | Broj odjela |
| `Odsjek` | integer | Broj odsjeka |
| `Povr. (ha)` | decimal | Površina odsjeka u hektarima (zarez kao decimalni separator) |
| `Gazd. Klasa` | string | Šifra gospodarske klase |
| `Vrsta` | string | `Lišćari` ili `Četinari` |
| `Šifra` | string | Šifra vrste drveta (prazno za zbirne redove) |
| `Naziv drveta` | string | Naziv vrste ili oznaka zbirnog reda |
| `Bonitet` | integer | Bonitetna klasa staništa (1–5) |
| `Kl. 0-5` | integer | Broj stabala/ha, debljinska klasa 0–5 cm |
| `Kl. 6-10` | integer | Broj stabala/ha, debljinska klasa 6–10 cm |
| `Kl. 11-20` | integer | Broj stabala/ha, debljinska klasa 11–20 cm |
| `Kl. 21-30` | integer | Broj stabala/ha, debljinska klasa 21–30 cm |
| `Kl. 31-50` | integer | Broj stabala/ha, debljinska klasa 31–50 cm |
| `Kl. 51-80` | integer | Broj stabala/ha, debljinska klasa 51–80 cm |
| `Kl. >80` | integer | Broj stabala/ha, debljinska klasa >80 cm |
| `Ukupno` | integer | Ukupan broj stabala/ha (sve klase) |
| `Temeljnica (m²/ha)` | decimal | Temeljnica u m² po hektaru |
| `Tip` | string | `Vrsta` / `Ukupno vrsta` / `Ukupno odsjek` |

### Vrijednosti kolone `Tip`

| Vrijednost | Opis |
|------------|------|
| `Vrsta` | Red za pojedinu vrstu drveta unutar odsjeka |
| `Ukupno vrsta` | Zbirni red za lišćare ili četinare u odsjeku |
| `Ukupno odsjek` | Zbirni red za cijeli odsjek |

## Statistika

| GJ | Odjela | Redova |
|----|--------|--------|
| RISOVAC KRUPA | 149 | 2.007 |
| GRMEČ JASENICA | 62 | 2.409 |
| BAŠTRA ĆORKOVAČA | 73 | 1.467 |
| GOMILA | 87 | 1.216 |
| VOJSKOVA | 62 | 889 |
| **UKUPNO** | **433** | **7.988** |

## Napomene

- Decimalni separator u CSV-u je **tačka** (`.`) — konvertovano iz originalnog formata sa zarezom.
- Kolone debljinskih klasa su **broj stabala po hektaru** (N/ha), ne apsolutni broj.
- Zbirni redovi (`Ukupno vrsta`, `Ukupno odsjek`) imaju prazne kolone `Šifra` i `Bonitet`.
